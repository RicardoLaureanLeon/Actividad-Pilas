
package pilaconnodos;

public class Main {
    public static void main(String[] args) {
        Pila<String> pila = new Pila<>();

        System.out.println(
            "¿Está vacía? " + pila.empty()
        );

        pila.push("Manzana");
        pila.push("Pera");
        pila.push("Naranja");

        System.out.println(
            "Cantidad de elementos: " + pila.size()
        );

        System.out.println(
            "Tope de la pila: " + pila.peek()
        );

        System.out.println(
            "Elemento extraído: " + pila.pop()
        );

        System.out.println(
            "Nuevo tope: " + pila.peek()
        );

        System.out.println(
            "Elemento extraído: " + pila.pop()
        );

        System.out.println(
            "Elemento extraído: " + pila.pop()
        );

        System.out.println(
            "¿Está vacía? " + pila.empty()
        );

        System.out.println(
            "Cantidad de elementos: " + pila.size()
        );

        try {
            pila.pop();
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
