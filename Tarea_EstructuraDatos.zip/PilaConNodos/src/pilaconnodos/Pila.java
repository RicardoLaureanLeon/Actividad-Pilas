
package pilaconnodos;

public class Pila<T> {
    private Nodo<T> tope;
    private int nElementos;

    // Constructor: crea una pila vacía
    public Pila() {
        tope = null;
        nElementos = 0;
    }

    // Agrega un elemento al tope
    public void push(T elemento) {
        Nodo<T> nuevo = new Nodo<>(elemento);
        nuevo.setSiguiente(tope);
        tope = nuevo;
        nElementos++;
    }

    // Extrae y devuelve el elemento del tope
    public T pop() {
        if (empty()) {
            throw new IllegalStateException(
                "La pila está vacía."
            );
        }

        T elemento = tope.getDato();
        tope = tope.getSiguiente();
        nElementos--;
        return elemento;
    }

    // Consulta el tope sin extraerlo
    public T peek() {
        if (empty()) {
            throw new IllegalStateException(
                "La pila está vacía."
            );
        }

        return tope.getDato();
    }

    // Verifica si la pila está vacía
    public boolean empty() {
        return nElementos == 0;
    }

    // Devuelve el número de elementos
    public int size() {
        return nElementos;
    }
}
